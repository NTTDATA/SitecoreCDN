In your web.config, 
1. under /system.webserver/handlers/

ADD

<add verb="*" path="aws_minify.ashx" type="NTTData.SitecoreCDN.Handlers.MinifyHandler, NTTData.SitecoreCDN" name="SitecoreCDN.Minify" />

BEFORE

<add verb="*" path="sitecore_handlers.ashx" type="Sitecore.Web.CustomHandlerFactory, Sitecore.Kernel" name="Sitecore.GenericHandler"/>
      
2. under /system.web/httpHandlers/

ADD

<add path="aws_minify.ashx" verb="*" type="NTTData.SitecoreCDN.Handlers.MinifyHandler, NTTData.SitecoreCDN" />

BEFORE

<add verb="*" path="sitecore_handlers.ashx" type="Sitecore.Web.CustomHandlerFactory, Sitecore.Kernel"/>

3. in /App_Config/Includes/SitecoreCDN.config set the hostname of your CDN per site.

<sites>
  <site name="website">
    <patch:attribute name="cdnHostName">yourcdnhostname</patch:attribute>
  </site>
</sites>